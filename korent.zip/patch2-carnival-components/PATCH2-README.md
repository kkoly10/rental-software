# Patch 2 — Shared Components & List Tabs

Applies the Patch 1 utility layer to the real shared components, then adopts them in
the four operator list tabs. **Requires Patch 1 first** (the `globals.css` utilities
this code references).

```
NEW   components/ui/entity-row.tsx          ← the one crafted list primitive + helpers
EDIT  components/ui/status-badge.tsx        ← flat .badge → dotted .pill
EDIT  components/ui/stat-card.tsx           ← optional icon / accent / trend (back-compatible)
EDIT  app/dashboard/orders/page.tsx         ← list rows → <EntityRow> (date-chip + accent + weather)
EDIT  app/dashboard/products/page.tsx       ← list rows → <EntityRow> (icon chip)
EDIT  app/dashboard/payments/page.tsx       ← list rows → <EntityRow> (status-tinted $ chip)
EDIT  app/dashboard/customers/page.tsx      ← list rows → <EntityRow> (initials avatar)
```

All edits preserve every existing import, data fetcher, search form, pagination,
empty state, i18n string, and CSV/QuickBooks export. **Only the row markup changed.**

---

## Components

### `EntityRow` (new) — `components/ui/entity-row.tsx`
One primitive replacing the shared flat `.order-card`. Props: `leading`, `title`,
`meta`, `trailing`, `accent` (left status edge), `href`. Trailing nodes render as flex
siblings so the row `gap` spaces them. Ships with helpers used by the pages:
- `DateChip({ iso })` — stacked MON / DD from an ISO date
- `AvatarChip({ name, color })` — initials in a tinted circle
- `IconChip({ children, color })` — line icon in a tinted square
- `RowFigure` — right-aligned headline number
- `toneColor` — maps `tone` → CSS color for the accent edge

### `StatusBadge` — now a dotted tonal **pill**
Same API. `tone` is now a superset (`+ "info" | "accent"`), so every existing call
keeps working — it just renders `.pill .pill--<tone>` instead of `.badge`.

### `StatCard` — optional craft, back-compatible
Existing `{ label, value, meta }` calls now get an **eyebrow label + tabular value**
for free (this alone upgrades all 8 Analytics cards). New optional props:
`icon` (line icon in a tinted chip), `accent` (domain color → chip + left edge),
`trend` (`{ dir, text }`). When none are passed it's the plain card, unchanged.

---

## What each tab gains

| Tab | Leading visual | Other craft |
|---|---|---|
| **Orders** | `DateChip` from `eventDateRaw` | status-color left edge (`toneColor[tone]`), kept `WeatherBadge`, dotted pill, tabular total via `RowFigure` |
| **Products** | `IconChip` (box) | dotted status pill, tabular price |
| **Payments** | `IconChip` tinted by status (green paid / red failed / amber pending) | tabular amount + dotted pill |
| **Customers** | `AvatarChip` (initials, tinted) | contact line + tabular phone, "Latest:" line, right-aligned date |

The search "no results" cards also moved from `.order-card` to `.entity-row` for
consistency. `EmptyState` was reviewed and **left as-is** — it already ships
custom per-type SVG illustrations in the Carnival palette.

---

## Verified
Rendered against the **actual patched `globals.css`** (computed styles checked):
`.entity-row` ×5, avatar circle `border-radius: 999px` in accent violet, success-green
`.icon-chip`, `.pill--info` teal on info-bg, `.pill--danger` red, `DateChip` day output.

## Not in this patch (flagged for Patch 3 — needs data-layer changes)
- **Products photo grid** — `getProductsPage` doesn't return an image URL today; add
  `imageUrl` to the list query, then swap `IconChip` for `.product-thumb`.
- **Filter chips + tinted page-header hero** on list tabs — needs status-count
  aggregation in the data fetchers.
- Order detail, forms/auth, deliveries kanban, calendar grid (Patch 3 surfaces).

## Apply
1. Ship **Patch 1** first.
2. Add `entity-row.tsx`; replace the four `page.tsx` and the two `ui/` components.
3. `npm run dev` → Orders/Products/Payments/Customers now render crafted rows; nothing
   else changes. No data, route, or i18n changes required.
