# Patch 1 — Carnival Foundation

The highest-leverage pass: it lifts **every** page at once by (1) removing leftover
blue from the original theme and (2) adding a small layer of crafted utility classes
that the rest of the redesign builds on.

Two files change. Both are drop-in.

```
app/globals.css     ← blue cleanup + craft utility layer appended
app/layout.tsx      ← adds "DM Serif Display" to the font <link>
```

No markup changes are required to ship this patch — it's safe on its own. The new
utility classes are **opt-in**; nothing renders differently until you apply them
(that's Patch 2 & 3).

---

## 1. `app/globals.css`

### a) Blue-artifact cleanup (64 replacements)

The `:root` block was already Carnival, but ~64 hard-coded blues from the original
"blue/white SaaS" theme were still scattered through component styles. All replaced
with the matching Carnival token or a warm equivalent:

| Old (blue) | New (warm) | Where it showed |
|---|---|---|
| `rgba(30, 93, 207, α)` ×29 | `rgba(232, 89, 12, α)` | input focus rings, breadcrumb/cmd-palette/notif hovers, pill borders & tints |
| `rgba(16, 35, 63, α)` ×10 | `rgba(45, 31, 20, α)` | card / dropdown / modal shadows (navy → warm) |
| `rgba(15, 35, 64, α)` ×5 | `rgba(45, 31, 20, α)` | welcome / tour / cmd / mobile-menu overlays |
| `#edf4ff` ×5 | `#fdeee3` | `.badge` default, notification "order" icon bg |
| `#2b3b7c`, `#30456f`, `#2d4da4` | `var(--primary)` / `var(--text-soft)` | storefront logo, hero copy, kicker |
| `#0f2340` | `#2d1f14` | crew mobile-frame bezel |
| `#8899b3` | `var(--text-muted)` | "pain section" strike-through text |
| `#d9e7ff` `#f3f8ff` `#8fc5ff` `#dcecff` `#dce9fb` `#eef5ff` `#d8e7ff` `#f8fbff` | warm peach / sunset ramp | product-media, map-card, storefront gallery + thumbnails, category cards |
| stray `#2563eb` | `var(--primary)` | — |

Verified: `grep` for blue hex/rgba patterns returns **zero** matches after the patch.

### b) Craft utility layer (appended, ~+6.8 KB)

A commented block at the end of the file. Opt-in classes, all driven by existing
`--tokens`:

- `.tnum` — tabular figures (use on **every** number)
- `.eyebrow` / `.eyebrow--accent` / `.eyebrow--tick` — tracked uppercase micro-labels
- `.u-serif` — editorial DM Serif Display italic accent (use on **one** heading word)
- `.pill` + `.pill--success|warning|info|danger|accent` — dotted tonal status pill
- `.entity-row` (+ `.has-accent`, `--row-accent`) + `__title/__meta/__grow/__figure` — the
  one crafted row primitive the list tabs adopt in Patch 2
- `.date-chip`, `.avatar-chip`, `.icon-chip` — leading visuals
- `.stat-strip` (+ `--2/--3/--4`) + `.stat-strip__cell/__value` — summary card rows
- `.stat-card--craft` + `.stat-card__icon` — accent edge + icon chip for the existing `.stat-card`
- `.filter-chips` / `.filter-chip` (+ `--active`, `__n`) — status filter row
- `.segmented-progress` — pip-style setup progress
- `.activity` / `__item` / `__dot` — recent-activity timeline
- `.product-thumb` — catalog card image area
- `.hero-band` — tinted command-center header with subtle warm dot texture

## 2. `app/layout.tsx`

One line — the Google Fonts `<link>` now also loads **DM Serif Display** (for `.u-serif`):

```diff
- ...&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap
+ ...&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap
```

---

## Brand assets — already wired ✅

No action needed. `public/` already has favicon (`.ico`/`.svg`), `apple-touch-icon`,
`icon-192/512/1024`, maskable icon, `manifest.json`, `og-image.png`, and wordmarks;
`app/layout.tsx` already references them and sets `themeColor: #e8590c`. If you want the
OG/icon art refreshed to the current Carnival "Playful K", swap those files in place
(same names) — the wiring stays.

## How to apply

1. Replace `app/globals.css` and `app/layout.tsx` with the versions in this folder.
2. `npm run dev` — you should see warm focus rings, warm shadows, and no blue anywhere.
3. Nothing else changes visually yet — Patch 2 applies the new classes to
   `StatusBadge`, `StatCard`, `EmptyState`, and the shared `EntityRow`.

> Note: `app/storefront-theme.css` (imported alongside `globals.css`) was reviewed and
> needs **no changes** — it's fully token-based (`--st-primary: var(--primary)`), so it
> already inherits the Carnival orange. The only cool values left are near-black shadow
> tints (`rgba(15, 31, 51, …)`); warming them to `rgba(45, 31, 20, …)` is an optional,
> barely-perceptible nicety, not a blue-bleed fix.
