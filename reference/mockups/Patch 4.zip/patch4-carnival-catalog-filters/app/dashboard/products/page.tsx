import Link from "next/link";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import { StatusBadge } from "@/components/ui/status-badge";
import { EmptyState } from "@/components/dashboard/empty-state";
import { getProductsPage } from "@/lib/data/products";
import { getGuidanceState } from "@/lib/guidance/actions";
import { pageHelpMap } from "@/lib/help/page-help";
import { ContextHelpBanner } from "@/components/guidance/context-help-banner";
import { ListSearchForm } from "@/components/dashboard/list-search-form";
import { ListPagination } from "@/components/dashboard/list-pagination";
import { CsvImportButton } from "@/components/products/csv-import-button";
import { getTranslator } from "@/lib/i18n/server";

// Tinted placeholder glyph when a product has no photo yet.
function BoxGlyph() {
  return (
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 8l-9-5-9 5 9 5 9-5z" />
      <path d="M3 8v8l9 5 9-5V8" />
      <path d="M12 13v8" />
    </svg>
  );
}

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string }>;
}) {
  const params = await searchParams;
  const [productsPage, guidanceState, { messages: m, t }] = await Promise.all([
    getProductsPage({ query: params.q, page: params.page }),
    getGuidanceState(),
    getTranslator(),
  ]);
  const helpConfig = pageHelpMap["/dashboard/products"];

  return (
    <DashboardShell
      title={m.dashboard.products.title}
      description={m.dashboard.products.description}
    >
      {/* Patch 4 — tinted hero header */}
      <div className="tab-hero">
        <div>
          <div className="eyebrow eyebrow--accent eyebrow--tick">{m.dashboard.products.kicker}</div>
          <h1 className="tab-hero__title">{m.dashboard.products.sectionTitle}</h1>
          <p className="tab-hero__sub">
            {t(productsPage.totalItems === 1 ? m.dashboard.products.matchingFound : m.dashboard.products.matchingFoundPlural, { count: productsPage.totalItems })}
          </p>
        </div>
        <div className="tab-hero__actions">
          <CsvImportButton />
          <Link href="/dashboard/products/new" className="primary-btn">
            {m.dashboard.products.newProduct}
          </Link>
        </div>
      </div>

      {helpConfig && (
        <ContextHelpBanner
          config={helpConfig}
          dismissed={guidanceState.dismissedHelp[helpConfig.key] ?? false}
        />
      )}

      <section className="panel">
        <ListSearchForm
          placeholder={m.dashboard.products.searchPlaceholder}
          initialQuery={productsPage.query}
        />

        {productsPage.items.length === 0 ? (
          productsPage.query ? (
            <div className="entity-row" style={{ justifyContent: "center", padding: 32, marginTop: 14 }}>
              <div style={{ textAlign: "center" }}>
                <strong>{m.dashboard.products.noProductsFound}</strong>
                <div className="muted" style={{ marginTop: 8 }}>{m.common.tryDifferentSearch}</div>
              </div>
            </div>
          ) : (
            <EmptyState
              icon="products"
              title={m.dashboard.products.noProductsYet}
              description={m.dashboard.products.noProductsYetDescription}
              actionLabel={m.dashboard.products.createProduct}
              actionHref="/dashboard/products/new"
            />
          )
        ) : (
          <>
            {/* Patch 4 — catalog photo grid */}
            <div className="product-grid" style={{ marginTop: 14 }}>
              {productsPage.items.map((product) => (
                <Link
                  key={product.id}
                  href={`/dashboard/products/${product.id}`}
                  className="product-card"
                >
                  <div className="product-card__thumb">
                    {product.imageUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={product.imageUrl} alt={product.name} />
                    ) : (
                      <div className="product-card__ph"><BoxGlyph /></div>
                    )}
                    <span className="product-card__status">
                      <StatusBadge
                        label={product.status}
                        tone={product.tone as "default" | "success" | "warning" | "danger"}
                      />
                    </span>
                  </div>
                  <div className="product-card__body">
                    <div className="product-card__cat">{product.category}</div>
                    <div className="product-card__name">{product.name}</div>
                    <div className="product-card__foot">
                      <span className="product-card__price">{product.price}</span>
                      {product.missingPrice && (
                        <StatusBadge label={m.dashboard.products.unpriced ?? "No price"} tone="warning" />
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            <ListPagination
              pathname="/dashboard/products"
              page={productsPage.page}
              totalPages={productsPage.totalPages}
              query={productsPage.query}
            />
          </>
        )}
      </section>
    </DashboardShell>
  );
}
