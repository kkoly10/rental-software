# Patch 4 — Catalog Photo Grid + Order Filter Chips

The first patch with **data-layer changes**. Adds real product photos to the catalog
and live status filtering to Orders. Requires Patch 1 (utilities) + Patch 2 (EntityRow);
the new grid/hero CSS goes in `globals-patch4-additions.css`.

```
TYPE   lib/types.ts                                  ← one-line: ProductSummary.imageUrl  (diff below)
EDIT   lib/data/products.ts                          ← join product_images, populate imageUrl
EDIT   lib/data/orders.ts                            ← status filter + getOrderStatusCounts()
NEW    components/dashboard/list-filter-chips.tsx    ← presentational chip row
EDIT   app/dashboard/products/page.tsx               ← IconChip rows → photo grid
EDIT   app/dashboard/orders/page.tsx                 ← hero band + filter chips
APPEND globals-patch4-additions.css                 → end of app/globals.css
```

---

## Data layer

### `lib/types.ts` — one line
```diff
 export type ProductSummary = {
   id: string;
   name: string;
   category: string;
   price: string;
   status: string;
   tone: StatusTone;
+  /** Patch 4 — primary product photo for the catalog grid. */
+  imageUrl?: string;
   missingPrice?: boolean;
   hasOpenMaintenance?: boolean;
 };
```

### `lib/data/products.ts`
- `selectFields` now embeds `product_images(image_url, is_primary, sort_order)`.
- `pickPrimaryImage()` chooses `is_primary` first, then lowest `sort_order`.
- `mapProductRow` sets `imageUrl`. No image → `undefined` → grid renders the tinted
  placeholder. Mock mode leaves it undefined (safe).

### `lib/data/orders.ts`
- `getOrdersPage({ status })` — new optional param. The browse (no-query) path applies
  `.in("order_status", …)` via `statusGroupValues()`; mock mode mirrors it with
  `mockMatchesStatusGroup()`. Free-text search path is unchanged.
- `getOrderStatusCounts()` — returns counts per chip group using cheap
  `head:true` count queries (covered by the existing `idx_orders_org_status` index);
  mock mode tallies `mockOrders`. Groups: all / inquiry / quote_sent / awaiting_deposit
  / confirmed / completed (= completed + delivered) / cancelled (= cancelled + refunded).

---

## UI

### Products → **catalog photo grid**
The `EntityRow` list (Patch 2) becomes a responsive `.product-grid` of `.product-card`
links: 4:3 photo (or tinted box-glyph placeholder), status pill overlaid top-left,
category, name, tabular price, and a "No price" warning pill when `missingPrice`.

### Orders → **hero band + filter chips**
- A tinted, dot-textured `.tab-hero` header (eyebrow + Sora title + count + actions)
  replaces the in-panel section header.
- `ListFilterChips` renders the seven status chips with live counts; the active chip
  is the solid dark `.filter-chip--active`. Chips set/clear `?status=` while preserving
  the search query; the empty state now also trips when a filter yields nothing.

Both pages keep every existing import, search form, pagination, empty state, i18n
call, and CSV/import action.

> **i18n note:** chip labels and the "No price" label read from
> `m.dashboard.orders.filters.*` / `m.dashboard.products.unpriced` with English
> fallbacks (`?? "All"` etc.), so the patch compiles before you add those keys — add
> them to your locale files when convenient.

---

## Verified
Rendered against the real `globals.css` + additions: orders hero band, all seven chips
with counts + dark active state, dotted-pill order rows; products grid with real photos,
overlaid status pills, and the tinted placeholder for an unphotographed item.

## Apply
1. Apply the one-line `types.ts` diff.
2. Replace `lib/data/products.ts`, `lib/data/orders.ts`, the two `page.tsx` files;
   add `list-filter-chips.tsx`; append the CSS.
3. `npm run dev` → Products shows photos, Orders filters by status with live counts.

## Still ahead (Patch 5 — larger surfaces)
- **New-order / product forms** (multi-step craft, inflatable-setup accordion)
- **Deliveries kanban** + **calendar month grid**
- Optional: extend filter chips to Payments (by `payment_status`) and a Products
  active/hidden toggle.
