import Link from "next/link";

export type FilterChip = { key: string; label: string; count: number };

/**
 * Patch 4 — status filter chips for list tabs. Presentational: renders
 * `.filter-chip` links that set/clear the `?status=` param while preserving
 * the current search query. Active chip = the matching `status` (or "all"
 * when none is set).
 */
export function ListFilterChips({
  basePath,
  activeStatus,
  query,
  chips,
}: {
  basePath: string;
  activeStatus?: string;
  query?: string;
  chips: FilterChip[];
}) {
  return (
    <div className="filter-chips" role="tablist" aria-label="Filter by status">
      {chips.map((chip) => {
        const isActive =
          chip.key === activeStatus || (chip.key === "all" && !activeStatus);
        const params = new URLSearchParams();
        if (chip.key !== "all") params.set("status", chip.key);
        if (query) params.set("q", query);
        const qs = params.toString();
        return (
          <Link
            key={chip.key}
            href={qs ? `${basePath}?${qs}` : basePath}
            role="tab"
            aria-selected={isActive}
            className={`filter-chip${isActive ? " filter-chip--active" : ""}`}
          >
            {chip.label}
            <span className="filter-chip__n">{chip.count}</span>
          </Link>
        );
      })}
    </div>
  );
}
