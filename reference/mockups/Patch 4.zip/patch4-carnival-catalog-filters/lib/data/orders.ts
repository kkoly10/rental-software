import { mockOrders } from "@/lib/mock-data";
import { hasSupabaseEnv } from "@/lib/env";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { getOrgContext } from "@/lib/auth/org-context";
import {
  paginateItems,
  type PaginatedResult,
  normalizeQuery,
  normalizePage,
} from "@/lib/listing/pagination";
import { escapeIlike } from "@/lib/listing/ilike-escape";
import type { OrderSummary } from "@/lib/types";

function formatStatus(status: string): string {
  return status.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function statusTone(status: string): OrderSummary["tone"] {
  if (
    status === "confirmed" ||
    status === "completed" ||
    status === "delivered"
  ) {
    return "success";
  }
  if (status === "awaiting_deposit" || status === "quote_sent") {
    return "warning";
  }
  if (status === "cancelled" || status === "refunded") {
    return "danger";
  }
  return "default";
}

// Patch 4: filter-chip group key → order_status value(s). null = All (no filter).
function statusGroupValues(group?: string | null): string[] | null {
  switch (group) {
    case "inquiry":
      return ["inquiry"];
    case "quote_sent":
      return ["quote_sent"];
    case "awaiting_deposit":
      return ["awaiting_deposit"];
    case "confirmed":
      return ["confirmed"];
    case "completed":
      return ["completed", "delivered"];
    case "cancelled":
      return ["cancelled", "refunded"];
    default:
      return null;
  }
}

// Mock-mode equivalent: compare a formatted OrderSummary.status against a group.
function mockMatchesStatusGroup(order: OrderSummary, group?: string | null): boolean {
  const values = statusGroupValues(group);
  if (!values) return true;
  const key = order.status.toLowerCase().replace(/ /g, "_");
  return values.includes(key);
}

type OrderRow = {
  id: string;
  order_number: string | null;
  order_status: string | null;
  event_date: string | null;
  total_amount: number | string | null;
};

function mapOrderRow(order: OrderRow): OrderSummary {
  const customer = (order as Record<string, unknown>).customers as
    | { first_name?: string | null; last_name?: string | null; deleted_at?: string | null }
    | null;
  const items =
    ((order as Record<string, unknown>).order_items as
      | { item_name_snapshot?: string | null }[]
      | null) ?? [];
  const address = (order as Record<string, unknown>).customer_addresses as
    | { postal_code?: string | null }
    | null;
  const status = order.order_status ?? "inquiry";
  const customerLabel =
    customer && !customer.deleted_at
      ? `${customer.first_name ?? ""} ${customer.last_name ?? ""}`.trim()
      : "";
  return {
    id: order.id,
    customer: customerLabel || (order.order_number ?? "Order"),
    item:
      items.length > 0
        ? items.map((i) => i.item_name_snapshot).filter(Boolean).join(", ")
        : "Rental booking",
    date: order.event_date
      ? new Date(order.event_date + "T12:00:00Z").toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
          timeZone: "UTC",
        })
      : "TBD",
    total: `$${Number(order.total_amount ?? 0).toFixed(2)}`,
    status: formatStatus(status),
    tone: statusTone(status),
    eventDateRaw: order.event_date ?? undefined,
    postalCode: address?.postal_code ?? undefined,
  };
}

function matchesOrderQuery(order: OrderSummary, query: string) {
  if (!query) return true;

  const haystack = [
    order.customer,
    order.item,
    order.date,
    order.total,
    order.status,
    order.id,
  ]
    .join(" ")
    .toLowerCase();

  return haystack.includes(query.toLowerCase());
}

export async function getOrdersPage(options?: {
  page?: string | number | null;
  query?: string | null;
  pageSize?: number;
  status?: string | null;
}): Promise<PaginatedResult<OrderSummary>> {
  const query = normalizeQuery(options?.query);

  if (!hasSupabaseEnv()) {
    const filtered = mockOrders.filter(
      (order) =>
        matchesOrderQuery(order, query) &&
        mockMatchesStatusGroup(order, options?.status)
    );
    return paginateItems(filtered, {
      page: options?.page,
      pageSize: options?.pageSize ?? 20,
      query,
    });
  }

  const ctx = await getOrgContext();
  if (!ctx) {
    return paginateItems([], { page: options?.page, pageSize: options?.pageSize ?? 20, query });
  }

  const supabase = await createSupabaseServerClient();
  const selectFields =
    "id, order_number, order_status, event_date, total_amount, customers(first_name, last_name, deleted_at), order_items(item_name_snapshot), customer_addresses!delivery_address_id(postal_code)";
  const pageSize = options?.pageSize ?? 20;

  // No-query path: paginate + count at the DB so every order is reachable and
  // totals are accurate (no silent 500-row JS truncation).
  if (!query) {
    const currentPage = normalizePage(options?.page);
    const start = (currentPage - 1) * pageSize;
    const end = start + pageSize - 1;
    // Patch 4: optional status filter drives the list-tab filter chips.
    let browseQuery = supabase
      .from("orders")
      .select(selectFields, { count: "exact" })
      .eq("organization_id", ctx.organizationId)
      .is("deleted_at", null);
    const statusValues = statusGroupValues(options?.status);
    if (statusValues) {
      browseQuery = browseQuery.in("order_status", statusValues);
    }
    const { data, error, count } = await browseQuery
      .order("created_at", { ascending: false })
      .range(start, end);

    if (error) {
      console.error("[orders] Query failed:", error.message);
      return paginateItems([], { page: options?.page, pageSize, query });
    }

    const mappedPage = (data ?? []).map(mapOrderRow);
    const totalItems = count ?? mappedPage.length;
    const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
    return {
      items: mappedPage,
      page: Math.min(currentPage, totalPages),
      pageSize,
      totalItems,
      totalPages,
      query: "",
    };
  }

  // Search path. Push to Postgres in two steps so the OR can span the
  // related customers table:
  //   1. Resolve customer-name matches to a list of customer_id values
  //      (capped, since we have to inline them into the orders OR clause
  //       and PostgREST URLs have a ceiling).
  //   2. Filter orders by order_number ILIKE OR customer_id IN (...).
  // Embedded `items` snapshots are not searched at the DB level —
  // operators searching by item name are rare and that surface still has
  // the truncation telemetry from #177.
  const currentPage = normalizePage(options?.page);
  const start = (currentPage - 1) * pageSize;
  const end = start + pageSize - 1;
  const safe = escapeIlike(query);
  const pattern = `%${safe}%`;

  // Step 1: customer-name → ids. Capped so the IN list stays short.
  const NAME_MATCH_CAP = 200;
  const { data: nameMatches, error: nameError } = await supabase
    .from("customers")
    .select("id")
    .eq("organization_id", ctx.organizationId)
    .is("deleted_at", null)
    .or(`first_name.ilike.${pattern},last_name.ilike.${pattern}`)
    .limit(NAME_MATCH_CAP);

  if (nameError) {
    console.error("[orders] Customer-name lookup failed:", nameError.message);
    // Fall through with no customer ids; order-number search still works.
  }
  const matchedIds = (nameMatches ?? []).map((c) => c.id);

  // Step 2: orders by order_number OR customer_id IN (...).
  let orFilter = `order_number.ilike.${pattern}`;
  if (matchedIds.length > 0) {
    orFilter += `,customer_id.in.(${matchedIds.join(",")})`;
  }

  const { data, error, count } = await supabase
    .from("orders")
    .select(selectFields, { count: "exact" })
    .eq("organization_id", ctx.organizationId)
    .is("deleted_at", null)
    .or(orFilter)
    .order("created_at", { ascending: false })
    .range(start, end);

  if (error) {
    console.error("[orders] Search query failed:", error.message);
    return paginateItems([], { page: options?.page, pageSize, query });
  }

  const mapped: OrderSummary[] = (data ?? []).map(mapOrderRow);
  const totalItems = count ?? mapped.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));

  return {
    items: mapped,
    page: Math.min(currentPage, totalPages),
    pageSize,
    totalItems,
    totalPages,
    query,
  };
}

export async function getOrders(): Promise<OrderSummary[]> {
  const result = await getOrdersPage();
  return result.items;
}

// Patch 4: per-status-group counts for the Orders filter chips. Uses cheap
// head:true count queries (covered by idx_orders_org_status). Mock mode tallies
// mockOrders. Groups mirror statusGroupValues().
export type OrderStatusCounts = {
  all: number;
  inquiry: number;
  quote_sent: number;
  awaiting_deposit: number;
  confirmed: number;
  completed: number;
  cancelled: number;
};

const EMPTY_COUNTS: OrderStatusCounts = {
  all: 0,
  inquiry: 0,
  quote_sent: 0,
  awaiting_deposit: 0,
  confirmed: 0,
  completed: 0,
  cancelled: 0,
};

export async function getOrderStatusCounts(): Promise<OrderStatusCounts> {
  if (!hasSupabaseEnv()) {
    const counts: OrderStatusCounts = { ...EMPTY_COUNTS };
    for (const order of mockOrders) {
      counts.all += 1;
      const key = order.status.toLowerCase().replace(/ /g, "_");
      if (key === "inquiry") counts.inquiry += 1;
      else if (key === "quote_sent") counts.quote_sent += 1;
      else if (key === "awaiting_deposit") counts.awaiting_deposit += 1;
      else if (key === "confirmed") counts.confirmed += 1;
      else if (key === "completed" || key === "delivered") counts.completed += 1;
      else if (key === "cancelled" || key === "refunded") counts.cancelled += 1;
    }
    return counts;
  }

  const ctx = await getOrgContext();
  if (!ctx) return { ...EMPTY_COUNTS };

  const supabase = await createSupabaseServerClient();
  const groups: Record<keyof OrderStatusCounts, string[] | null> = {
    all: null,
    inquiry: ["inquiry"],
    quote_sent: ["quote_sent"],
    awaiting_deposit: ["awaiting_deposit"],
    confirmed: ["confirmed"],
    completed: ["completed", "delivered"],
    cancelled: ["cancelled", "refunded"],
  };

  const entries = await Promise.all(
    (Object.entries(groups) as [keyof OrderStatusCounts, string[] | null][]).map(
      async ([key, values]) => {
        let q = supabase
          .from("orders")
          .select("id", { count: "exact", head: true })
          .eq("organization_id", ctx.organizationId)
          .is("deleted_at", null);
        if (values) q = q.in("order_status", values);
        const { count } = await q;
        return [key, count ?? 0] as const;
      }
    )
  );

  return { ...EMPTY_COUNTS, ...Object.fromEntries(entries) } as OrderStatusCounts;
}